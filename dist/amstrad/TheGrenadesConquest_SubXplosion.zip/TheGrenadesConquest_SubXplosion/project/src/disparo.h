// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_DISPARO_H_
#define _ASSETS_DISPARO_H_

#include <types.h>
#define PRE_DISPARO_W 2
#define PRE_DISPARO_H 5
extern const u8 pre_disparo[2 * 5];

#endif
