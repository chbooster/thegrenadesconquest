#include "disparo.h"
// Data created with Img2CPC - (c) Retroworks - 2007-2015
// Tile pre_disparo: 5x5 pixels, 2x5 bytes.
const u8 pre_disparo[2 * 5] = {
	0xf0, 0xf0,
	0xf5, 0xf0,
	0xf0, 0xf5,
	0xf0, 0xf0,
	0xf5, 0xf0,
};

