// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_TILESET_KCPC_H_
#define _ASSETS_TILESET_KCPC_H_

#include <types.h>
extern u8* const pre_tileset[60];

#define PRE_TILESET_KCPC_00_W 2
#define PRE_TILESET_KCPC_00_H 4
extern const u8 pre_tileset_kcpc_00[2 * 4];
#define PRE_TILESET_KCPC_01_W 2
#define PRE_TILESET_KCPC_01_H 4
extern const u8 pre_tileset_kcpc_01[2 * 4];
#define PRE_TILESET_KCPC_02_W 2
#define PRE_TILESET_KCPC_02_H 4
extern const u8 pre_tileset_kcpc_02[2 * 4];
#define PRE_TILESET_KCPC_03_W 2
#define PRE_TILESET_KCPC_03_H 4
extern const u8 pre_tileset_kcpc_03[2 * 4];
#define PRE_TILESET_KCPC_04_W 2
#define PRE_TILESET_KCPC_04_H 4
extern const u8 pre_tileset_kcpc_04[2 * 4];
#define PRE_TILESET_KCPC_05_W 2
#define PRE_TILESET_KCPC_05_H 4
extern const u8 pre_tileset_kcpc_05[2 * 4];
#define PRE_TILESET_KCPC_06_W 2
#define PRE_TILESET_KCPC_06_H 4
extern const u8 pre_tileset_kcpc_06[2 * 4];
#define PRE_TILESET_KCPC_07_W 2
#define PRE_TILESET_KCPC_07_H 4
extern const u8 pre_tileset_kcpc_07[2 * 4];
#define PRE_TILESET_KCPC_08_W 2
#define PRE_TILESET_KCPC_08_H 4
extern const u8 pre_tileset_kcpc_08[2 * 4];
#define PRE_TILESET_KCPC_09_W 2
#define PRE_TILESET_KCPC_09_H 4
extern const u8 pre_tileset_kcpc_09[2 * 4];
#define PRE_TILESET_KCPC_10_W 2
#define PRE_TILESET_KCPC_10_H 4
extern const u8 pre_tileset_kcpc_10[2 * 4];
#define PRE_TILESET_KCPC_11_W 2
#define PRE_TILESET_KCPC_11_H 4
extern const u8 pre_tileset_kcpc_11[2 * 4];
#define PRE_TILESET_KCPC_12_W 2
#define PRE_TILESET_KCPC_12_H 4
extern const u8 pre_tileset_kcpc_12[2 * 4];
#define PRE_TILESET_KCPC_13_W 2
#define PRE_TILESET_KCPC_13_H 4
extern const u8 pre_tileset_kcpc_13[2 * 4];
#define PRE_TILESET_KCPC_14_W 2
#define PRE_TILESET_KCPC_14_H 4
extern const u8 pre_tileset_kcpc_14[2 * 4];
#define PRE_TILESET_KCPC_15_W 2
#define PRE_TILESET_KCPC_15_H 4
extern const u8 pre_tileset_kcpc_15[2 * 4];
#define PRE_TILESET_KCPC_16_W 2
#define PRE_TILESET_KCPC_16_H 4
extern const u8 pre_tileset_kcpc_16[2 * 4];
#define PRE_TILESET_KCPC_17_W 2
#define PRE_TILESET_KCPC_17_H 4
extern const u8 pre_tileset_kcpc_17[2 * 4];
#define PRE_TILESET_KCPC_18_W 2
#define PRE_TILESET_KCPC_18_H 4
extern const u8 pre_tileset_kcpc_18[2 * 4];
#define PRE_TILESET_KCPC_19_W 2
#define PRE_TILESET_KCPC_19_H 4
extern const u8 pre_tileset_kcpc_19[2 * 4];
#define PRE_TILESET_KCPC_20_W 2
#define PRE_TILESET_KCPC_20_H 4
extern const u8 pre_tileset_kcpc_20[2 * 4];
#define PRE_TILESET_KCPC_21_W 2
#define PRE_TILESET_KCPC_21_H 4
extern const u8 pre_tileset_kcpc_21[2 * 4];
#define PRE_TILESET_KCPC_22_W 2
#define PRE_TILESET_KCPC_22_H 4
extern const u8 pre_tileset_kcpc_22[2 * 4];
#define PRE_TILESET_KCPC_23_W 2
#define PRE_TILESET_KCPC_23_H 4
extern const u8 pre_tileset_kcpc_23[2 * 4];
#define PRE_TILESET_KCPC_24_W 2
#define PRE_TILESET_KCPC_24_H 4
extern const u8 pre_tileset_kcpc_24[2 * 4];
#define PRE_TILESET_KCPC_25_W 2
#define PRE_TILESET_KCPC_25_H 4
extern const u8 pre_tileset_kcpc_25[2 * 4];
#define PRE_TILESET_KCPC_26_W 2
#define PRE_TILESET_KCPC_26_H 4
extern const u8 pre_tileset_kcpc_26[2 * 4];
#define PRE_TILESET_KCPC_27_W 2
#define PRE_TILESET_KCPC_27_H 4
extern const u8 pre_tileset_kcpc_27[2 * 4];
#define PRE_TILESET_KCPC_28_W 2
#define PRE_TILESET_KCPC_28_H 4
extern const u8 pre_tileset_kcpc_28[2 * 4];
#define PRE_TILESET_KCPC_29_W 2
#define PRE_TILESET_KCPC_29_H 4
extern const u8 pre_tileset_kcpc_29[2 * 4];
#define PRE_TILESET_KCPC_30_W 2
#define PRE_TILESET_KCPC_30_H 4
extern const u8 pre_tileset_kcpc_30[2 * 4];
#define PRE_TILESET_KCPC_31_W 2
#define PRE_TILESET_KCPC_31_H 4
extern const u8 pre_tileset_kcpc_31[2 * 4];
#define PRE_TILESET_KCPC_32_W 2
#define PRE_TILESET_KCPC_32_H 4
extern const u8 pre_tileset_kcpc_32[2 * 4];
#define PRE_TILESET_KCPC_33_W 2
#define PRE_TILESET_KCPC_33_H 4
extern const u8 pre_tileset_kcpc_33[2 * 4];
#define PRE_TILESET_KCPC_34_W 2
#define PRE_TILESET_KCPC_34_H 4
extern const u8 pre_tileset_kcpc_34[2 * 4];
#define PRE_TILESET_KCPC_35_W 2
#define PRE_TILESET_KCPC_35_H 4
extern const u8 pre_tileset_kcpc_35[2 * 4];
#define PRE_TILESET_KCPC_36_W 2
#define PRE_TILESET_KCPC_36_H 4
extern const u8 pre_tileset_kcpc_36[2 * 4];
#define PRE_TILESET_KCPC_37_W 2
#define PRE_TILESET_KCPC_37_H 4
extern const u8 pre_tileset_kcpc_37[2 * 4];
#define PRE_TILESET_KCPC_38_W 2
#define PRE_TILESET_KCPC_38_H 4
extern const u8 pre_tileset_kcpc_38[2 * 4];
#define PRE_TILESET_KCPC_39_W 2
#define PRE_TILESET_KCPC_39_H 4
extern const u8 pre_tileset_kcpc_39[2 * 4];
#define PRE_TILESET_KCPC_40_W 2
#define PRE_TILESET_KCPC_40_H 4
extern const u8 pre_tileset_kcpc_40[2 * 4];
#define PRE_TILESET_KCPC_41_W 2
#define PRE_TILESET_KCPC_41_H 4
extern const u8 pre_tileset_kcpc_41[2 * 4];
#define PRE_TILESET_KCPC_42_W 2
#define PRE_TILESET_KCPC_42_H 4
extern const u8 pre_tileset_kcpc_42[2 * 4];
#define PRE_TILESET_KCPC_43_W 2
#define PRE_TILESET_KCPC_43_H 4
extern const u8 pre_tileset_kcpc_43[2 * 4];
#define PRE_TILESET_KCPC_44_W 2
#define PRE_TILESET_KCPC_44_H 4
extern const u8 pre_tileset_kcpc_44[2 * 4];
#define PRE_TILESET_KCPC_45_W 2
#define PRE_TILESET_KCPC_45_H 4
extern const u8 pre_tileset_kcpc_45[2 * 4];
#define PRE_TILESET_KCPC_46_W 2
#define PRE_TILESET_KCPC_46_H 4
extern const u8 pre_tileset_kcpc_46[2 * 4];
#define PRE_TILESET_KCPC_47_W 2
#define PRE_TILESET_KCPC_47_H 4
extern const u8 pre_tileset_kcpc_47[2 * 4];
#define PRE_TILESET_KCPC_48_W 2
#define PRE_TILESET_KCPC_48_H 4
extern const u8 pre_tileset_kcpc_48[2 * 4];
#define PRE_TILESET_KCPC_49_W 2
#define PRE_TILESET_KCPC_49_H 4
extern const u8 pre_tileset_kcpc_49[2 * 4];
#define PRE_TILESET_KCPC_50_W 2
#define PRE_TILESET_KCPC_50_H 4
extern const u8 pre_tileset_kcpc_50[2 * 4];
#define PRE_TILESET_KCPC_51_W 2
#define PRE_TILESET_KCPC_51_H 4
extern const u8 pre_tileset_kcpc_51[2 * 4];
#define PRE_TILESET_KCPC_52_W 2
#define PRE_TILESET_KCPC_52_H 4
extern const u8 pre_tileset_kcpc_52[2 * 4];
#define PRE_TILESET_KCPC_53_W 2
#define PRE_TILESET_KCPC_53_H 4
extern const u8 pre_tileset_kcpc_53[2 * 4];
#define PRE_TILESET_KCPC_54_W 2
#define PRE_TILESET_KCPC_54_H 4
extern const u8 pre_tileset_kcpc_54[2 * 4];
#define PRE_TILESET_KCPC_55_W 2
#define PRE_TILESET_KCPC_55_H 4
extern const u8 pre_tileset_kcpc_55[2 * 4];
#define PRE_TILESET_KCPC_56_W 2
#define PRE_TILESET_KCPC_56_H 4
extern const u8 pre_tileset_kcpc_56[2 * 4];
#define PRE_TILESET_KCPC_57_W 2
#define PRE_TILESET_KCPC_57_H 4
extern const u8 pre_tileset_kcpc_57[2 * 4];
#define PRE_TILESET_KCPC_58_W 2
#define PRE_TILESET_KCPC_58_H 4
extern const u8 pre_tileset_kcpc_58[2 * 4];
#define PRE_TILESET_KCPC_59_W 2
#define PRE_TILESET_KCPC_59_H 4
extern const u8 pre_tileset_kcpc_59[2 * 4];

#endif
