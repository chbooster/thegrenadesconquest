//
// File assets/160x200.tmx converted to csv using cpct_tmx2csv [20161026 21:22:32 CEST]
//   * Width:  39 columns (39 bytes, 8 bits per column)
//   * Height: 50 rows
//   * Bytes:  1950 bytes (39 x 50)
//
#include <types.h>

// Generated CSV tilemap from assets/160x200.tmx
//   1950 bytes (39 x 50)
//   39*50 items (8 bits per item)
//
#define pre_terrain_W  39
#define pre_terrain_H  50
extern const u8 pre_terrain[39*50];
