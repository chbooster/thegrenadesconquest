// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_JIMMY_TILESET_H_
#define _ASSETS_JIMMY_TILESET_H_

#include <types.h>
extern const u8 pre_palette[16];

#define PRE_JIMMY_TILESET_00_W 5
#define PRE_JIMMY_TILESET_00_H 14
extern const u8 pre_jimmy_tileset_00[5 * 14];
#define PRE_JIMMY_TILESET_01_W 5
#define PRE_JIMMY_TILESET_01_H 14
extern const u8 pre_jimmy_tileset_01[5 * 14];
#define PRE_JIMMY_TILESET_02_W 5
#define PRE_JIMMY_TILESET_02_H 14
extern const u8 pre_jimmy_tileset_02[5 * 14];
#define PRE_JIMMY_TILESET_03_W 5
#define PRE_JIMMY_TILESET_03_H 14
extern const u8 pre_jimmy_tileset_03[5 * 14];
#define PRE_JIMMY_TILESET_04_W 5
#define PRE_JIMMY_TILESET_04_H 14
extern const u8 pre_jimmy_tileset_04[5 * 14];
#define PRE_JIMMY_TILESET_05_W 5
#define PRE_JIMMY_TILESET_05_H 14
extern const u8 pre_jimmy_tileset_05[5 * 14];
#define PRE_JIMMY_TILESET_06_W 5
#define PRE_JIMMY_TILESET_06_H 14
extern const u8 pre_jimmy_tileset_06[5 * 14];
#define PRE_JIMMY_TILESET_07_W 5
#define PRE_JIMMY_TILESET_07_H 14
extern const u8 pre_jimmy_tileset_07[5 * 14];
#define PRE_JIMMY_TILESET_08_W 5
#define PRE_JIMMY_TILESET_08_H 14
extern const u8 pre_jimmy_tileset_08[5 * 14];
#define PRE_JIMMY_TILESET_09_W 5
#define PRE_JIMMY_TILESET_09_H 14
extern const u8 pre_jimmy_tileset_09[5 * 14];
#define PRE_JIMMY_TILESET_10_W 5
#define PRE_JIMMY_TILESET_10_H 14
extern const u8 pre_jimmy_tileset_10[5 * 14];

#endif
