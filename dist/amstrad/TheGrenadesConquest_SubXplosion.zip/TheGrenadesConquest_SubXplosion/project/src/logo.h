// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_LOGO_H_
#define _ASSETS_LOGO_H_

#include <types.h>
#define PRE_LOGO_0_W 40
#define PRE_LOGO_0_H 66
extern const u8 pre_logo_0[40 * 66];
#define PRE_LOGO_1_W 40
#define PRE_LOGO_1_H 66
extern const u8 pre_logo_1[40 * 66];

#endif
