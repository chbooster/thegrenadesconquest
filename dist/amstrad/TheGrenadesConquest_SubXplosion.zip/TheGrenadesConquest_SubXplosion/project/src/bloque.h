// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_BLOQUE_H_
#define _ASSETS_BLOQUE_H_

#include <types.h>
#define PRE_BLOQUE_W 6
#define PRE_BLOQUE_H 16
extern const u8 pre_bloque[6 * 16];

#endif
