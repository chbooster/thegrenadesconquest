This is an academic project, licensed under GNU General Public License v3. 

This project was made at 2016 by Carlos Aniorte Llanes, Andreu Ord��ez Arboleda and Adri�n Garc�a Garc�a.

For this project, third party software used was: CPCtelera, Tiled and Cygwin.
Language used is C and was compiled with CPCtelera and Cygwin.
Thank you for give us your time to review our work.

SubXplosion Team - 2017

Adri�n Garc�a Garc�a		<adri1489ua@gmail.com>
Andreu Ord��ez Arboleda  	<ryasulion@gmail.com>
Carlos Aniorte Llanes           <carlos.aniortellanes@gmail.com>